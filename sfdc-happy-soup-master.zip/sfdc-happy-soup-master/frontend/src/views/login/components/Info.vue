<template>
   <div class="info">
      <div>
        <div class="is-size-5 ">
          <p class="has-text-weight-semibold"><i class="has-text-info fas fa-wallet"></i>  100% free and open source</p>
          <p class="is-size-6">Keeping your org clean and healthy is a basic right, so this one is on us!</p>
          <p class="has-text-weight-semibold"><i class="has-text-info fas fa-laptop-code"></i> Salesforce Impact Analysis</p>
          <p class="is-size-6">"Where is this used?" analysis across many metadata types</p>
          <p class="has-text-weight-semibold"><i class="has-text-info fas fa-file-code"></i> Salesforce Dependency Analysis</p>
          <p class="is-size-6">Visualize metadata dependencies in tree, csv and package.xml format</p>
          <p class="has-text-weight-semibold"><i class="has-text-info fas fa-sitemap"></i> The only way to discover Deployment Boundaries</p>
          <p class="is-size-6">Your org is made up of a large group of Deployment Boundaries, identify them in one click</p>
          <p class="has-text-weight-semibold"><i class="has-text-info fab fa-codepen"></i>  Break up your metadata and plan your move to SFDX</p>
          <p class="is-size-6">Export an entire Deployment Boundary in a deployment-ready package.xml to and deploy it to scratch orgs or unlocked packages</p>
          <p class="has-text-weight-semibold"> Not convinced? Watch an  <a target="_blank" href="https://www.youtube.com/watch?v=2asljhebqlY">awesome demo!</a> <i class="fab fa-youtube"></i></p>
        </div>  
    </div>
    </div>
</template>

<script>
export default {

}
</script>

<style lang="scss" scoped>

    

    .info{
        max-width: 500px;
    }

    p{
        margin-bottom: 15px;
    }

    iframe{
        width: 160;
        height: 115;
    }

    .pure-center{
        margin-top:3%;
    }

    .fa-youtube{
        color:rgb(232, 120, 120);
    }

    

</style>